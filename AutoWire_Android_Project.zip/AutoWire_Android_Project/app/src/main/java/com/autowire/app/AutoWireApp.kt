package com.autowire.app

import android.app.Application
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader

class AutoWireApp : Application() {
    override fun onCreate() {
        super.onCreate()
        PDFBoxResourceLoader.init(applicationContext)
    }
}
