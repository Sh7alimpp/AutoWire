package com.autowire.app

import java.io.File

data class DiagramItem(
    val path: List<String>,
    val title: String,
    val url: String
)

data class DiagramPayload(
    val type: String,
    val content: String,
    val ext: String = "",
    val subLabel: String = ""
)

data class DownloadedRecord(
    val path: List<String>,
    val title: String,
    val pdfFile: File
)

data class CategoryGroup(
    val name: String,
    val count: Int,
    val selected: Boolean = true
)

data class IncompleteJob(
    val dir: File,
    val dirName: String,
    val vehicleTitle: String,
    val catSuffix: String,
    val startUrl: String,
    val items: List<DiagramItem>,
    val done: Int,
    val total: Int
)

enum class AppPhase {
    IDLE,
    BROWSER,
    SELECTING,
    DOWNLOADING,
    PAUSED,
    BLOCKED,
    DONE,
    ERROR
}

data class UiState(
    val phase: AppPhase = AppPhase.IDLE,
    val urlInput: String = "",
    val vehicleTitle: String = "",
    val message: String = "جاهز — حط رابط العربية أو استكمل تحميل قديم.",
    val categories: List<CategoryGroup> = emptyList(),
    val totalItemsFound: Int = 0,
    val current: Int = 0,
    val total: Int = 0,
    val currentItem: String = "",
    val logs: List<String> = emptyList(),
    val incompleteJobs: List<IncompleteJob> = emptyList(),
    val finalPdfFile: File? = null,
    val ebayInfoFile: File? = null
)
