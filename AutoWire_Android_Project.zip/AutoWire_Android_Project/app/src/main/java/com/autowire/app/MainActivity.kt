package com.autowire.app

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.FileProvider
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import java.io.File
import java.text.SimpleDateFormat
import java.util.*
import kotlin.random.Random

class MainActivity : ComponentActivity() {

    private val _state = MutableStateFlow(UiState())
    val uiState = _state.asStateFlow()

    private var webViewRef: WebView? = null
    private var extractedItems: List<DiagramItem> = emptyList()
    private var downloadJob: Job? = null

    @Volatile private var isPaused = false
    @Volatile private var isStopped = false
    @Volatile private var retryClicked = false

    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    private val notifPermLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) {}

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            notifPermLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        refreshIncomplete()

        setContent {
            val st by uiState.collectAsState()
            AutoWireScreen(
                state = st,
                onUrlChange = { u -> _state.update { it.copy(urlInput = u) } },
                onOpenUrl = { openUrlInBrowser(st.urlInput) },
                onScanPage = { scanBrowserPage() },
                onToggleCategory = { idx ->
                    val list = st.categories.toMutableList()
                    list[idx] = list[idx].copy(selected = !list[idx].selected)
                    _state.update { it.copy(categories = list) }
                },
                onSelectAll = { sel ->
                    _state.update { it.copy(categories = it.categories.map { c -> c.copy(selected = sel) }) }
                },
                onStartDownload = { startSelectedDownload() },
                onResumeJob = { job -> resumeIncompleteJob(job) },
                onPauseToggle = { togglePause() },
                onStopDownload = { isStopped = true; isPaused = false; retryClicked = true },
                onRetryBlocked = { retryClicked = true },
                onReset = {
                    refreshIncomplete()
                    _state.update { it.copy(phase = AppPhase.IDLE, message = "جاهز — حط رابط جديد أو استكمل تحميل قديم.") }
                },
                onShareFile = { file -> shareFile(file) },
                onWebViewReady = { wv -> webViewRef = wv }
            )
        }
    }

    private fun log(msg: String) {
        val ts = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
        val line = "[$ts] $msg"
        _state.update { it.copy(logs = (it.logs + line).takeLast(80)) }
    }

    private fun refreshIncomplete() {
        val jobs = StorageManager.findIncompleteJobs(this)
        _state.update { it.copy(incompleteJobs = jobs) }
    }

    private fun openUrlInBrowser(rawUrl: String) {
        val u = rawUrl.trim()
        if (u.isEmpty()) return
        val full = if (u.startsWith("http")) u else "https://$u"
        _state.update { it.copy(phase = AppPhase.BROWSER, urlInput = full, message = "سجّل دخول أو اختار العربية في المتصفح، وبعدين دوس (فحص المخططات).") }
        webViewRef?.loadUrl(full)
    }

    private fun scanBrowserPage() {
        val wv = webViewRef ?: return
        scope.launch {
            _state.update { it.copy(message = "جاري فحص المخططات في الصفحة...") }
            WebExtractor.dismissOverlays(wv)
            val curUrl = WebExtractor.getCurrentUrl(wv)
            val items = WebExtractor.extractTreeItems(wv, curUrl)
            val vTitle = WebExtractor.extractVehicleTitle(wv)
            extractedItems = items

            if (items.isEmpty()) {
                _state.update { it.copy(phase = AppPhase.BROWSER, vehicleTitle = vTitle, message = "لسه مفيش مخططات ظاهرة. اتأكد إن القايمة فتحت ودوس (فحص المخططات) تاني.") }
                log("0 items found on page.")
                return@launch
            }

            val counts = linkedMapOf<String, Int>()
            for (it in items) {
                val cat = it.path.firstOrNull() ?: "General"
                counts[cat] = (counts[cat] ?: 0) + 1
            }
            val groups = counts.entries.map { CategoryGroup(it.key, it.value, true) }
            _state.update {
                it.copy(
                    phase = AppPhase.SELECTING,
                    vehicleTitle = vTitle,
                    categories = groups,
                    totalItemsFound = items.size,
                    message = "تم العثور على ${items.size} مخطط لـ $vTitle"
                )
            }
            log("Found ${items.size} items across ${groups.size} categories.")
        }
    }

    private fun startSelectedDownload() {
        val st = _state.value
        val selectedCats = st.categories.filter { it.selected }.map { it.name }.toSet()
        val filtered = if (selectedCats.isEmpty()) extractedItems else extractedItems.filter {
            (it.path.firstOrNull() ?: "General") in selectedCats
        }
        val catSuffix = if (selectedCats.size < st.categories.size) selectedCats.take(2).joinToString("_") else ""
        val outDir = StorageManager.buildOutputFolder(this, st.urlInput, st.vehicleTitle, catSuffix)
        runDownload(filtered, st.vehicleTitle, catSuffix, st.urlInput, outDir)
    }

    private fun resumeIncompleteJob(job: IncompleteJob) {
        _state.update { it.copy(phase = AppPhase.BROWSER, urlInput = job.startUrl) }
        scope.launch {
            val wv = webViewRef
            if (wv != null && job.startUrl.isNotEmpty()) {
                WebExtractor.navigateAndWait(wv, job.startUrl, 1500)
            }
            runDownload(job.items, job.vehicleTitle, job.catSuffix, job.startUrl, job.dir)
        }
    }

    private fun togglePause() {
        isPaused = !isPaused
        _state.update {
            it.copy(
                phase = if (isPaused) AppPhase.PAUSED else AppPhase.DOWNLOADING,
                message = if (isPaused) "متوقف مؤقتاً — دوس استئناف لما تحب تكمل." else "جاري استكمال التحميل..."
            )
        }
    }

    private fun runDownload(
        items: List<DiagramItem>,
        vehicleTitle: String,
        catSuffix: String,
        startUrl: String,
        outputDir: File
    ) {
        val wv = webViewRef ?: return
        isPaused = false
        isStopped = false
        retryClicked = false

        startForegroundService(Intent(this, DownloadService::class.java))

        downloadJob?.cancel()
        downloadJob = scope.launch {
            val pagesDir = File(outputDir, "pages").apply { mkdirs() }
            File(outputDir, "raw_diagrams").mkdirs()
            StorageManager.saveResumeState(outputDir, vehicleTitle, catSuffix, startUrl, items)

            val savedTitles = StorageManager.loadMetaTitles(outputDir)
            val incFile = File(outputDir, "_INCOMPLETE.txt")
            val okFile = File(outputDir, "_COMPLETE_OK.txt")
            if (okFile.exists()) okFile.delete()

            val records = mutableListOf<DownloadedRecord>()
            var doneCount = 0

            _state.update {
                it.copy(
                    phase = AppPhase.DOWNLOADING,
                    vehicleTitle = vehicleTitle,
                    current = 0,
                    total = items.size,
                    message = "جاري التحميل: $vehicleTitle"
                )
            }

            try {
                for ((i, item) in items.withIndex()) {
                    val idx = i + 1
                    while (isPaused && !isStopped) delay(300)
                    if (isStopped) break

                    val safeBase = "%03d_%s".format(idx, StorageManager.sanitizeFilename(item.title))
                    val firstPdf = File(pagesDir, "$safeBase.pdf")
                    _state.update { it.copy(current = idx, currentItem = item.title) }

                    val updIntent = Intent(this@MainActivity, DownloadService::class.java).apply {
                        action = DownloadService.ACTION_UPDATE
                        putExtra(DownloadService.EXTRA_TEXT, "$idx/${items.size}: ${item.title}")
                    }
                    startService(updIntent)

                    if (firstPdf.exists() && firstPdf.length() > 1000) {
                        log("[$idx/${items.size}] Skipping existing: ${item.title}")
                        val t0 = savedTitles[firstPdf.name] ?: item.title
                        records.add(DownloadedRecord(item.path, t0, firstPdf))
                        doneCount++
                        continue
                    }

                    log("[$idx/${items.size}] Downloading: ${item.title}")
                    var payloads: List<DiagramPayload> = emptyList()
                    while (!isStopped) {
                        try {
                            payloads = WebExtractor.fetchDiagramPayloads(wv, item.url)
                            break
                        } catch (e: Exception) {
                            log("[BLOCKED/ERR] ${e.message}")
                            _state.update {
                                it.copy(
                                    phase = AppPhase.BLOCKED,
                                    message = "الموقع وقف الطلبات مؤقتاً. استنى شوية أو غيّر الشبكة ودوس إعادة المحاولة."
                                )
                            }
                            retryClicked = false
                            while (!retryClicked && !isStopped) delay(300)
                            if (isStopped) break
                            _state.update { it.copy(phase = AppPhase.DOWNLOADING, message = "جاري التحميل: $vehicleTitle") }
                        }
                    }
                    if (isStopped) break

                    if (payloads.isEmpty()) {
                        log("  [WARN] Empty diagram: ${item.title}")
                    } else {
                        for ((si, payload) in payloads.withIndex()) {
                            val subIdx = si + 1
                            val outPdf = if (subIdx == 1) firstPdf else File(pagesDir, "${safeBase}_sub%02d.pdf".format(subIdx))
                            val bmTitle = if (subIdx == 1) item.title else "${item.title} (Page $subIdx)"
                            val header = "$vehicleTitle  |  ${item.path.joinToString(" > ")}  |  $bmTitle"
                            PdfEngine.renderDiagramToPdf(this@MainActivity, payload, header, outPdf)
                            savedTitles[outPdf.name] = bmTitle
                            records.add(DownloadedRecord(item.path, bmTitle, outPdf))
                        }
                        StorageManager.saveMetaTitles(outputDir, savedTitles)
                        doneCount++
                    }

                    incFile.writeText("Status: INCOMPLETE\nDownloaded: $doneCount/${items.size}\n", Charsets.UTF_8)

                    val delayMs = if (idx % 15 == 0) {
                        Random.nextLong(20000L, 30000L)
                    } else {
                        Random.nextLong(4500L, 7500L)
                    }
                    var waited = 0L
                    while (waited < delayMs && !isStopped) {
                        while (isPaused && !isStopped) delay(300)
                        delay(300)
                        waited += 300
                    }
                }

                var finalPdf: File? = null
                var ebayFile: File? = null
                if (records.isNotEmpty()) {
                    val cleanVeh = StorageManager.sanitizeFilename(vehicleTitle).replace(" ", "_")
                    val suf = if (catSuffix.isNotEmpty()) "_${StorageManager.sanitizeFilename(catSuffix).replace(" ", "_").take(30)}" else ""
                    val pdfName = if (isStopped) "${cleanVeh}${suf}_INCOMPLETE_Bookmarked.pdf" else "${cleanVeh}${suf}_Bookmarked.pdf"
                    finalPdf = File(outputDir, pdfName)
                    log("Merging ${records.size} pages into PDF...")
                    withContext(Dispatchers.IO) {
                        PdfEngine.mergePdfsWithBookmarks(records, finalPdf)
                    }
                    if (!isStopped) {
                        if (incFile.exists()) incFile.delete()
                        okFile.writeText("Status: COMPLETE\nPages: ${records.size}\n", Charsets.UTF_8)
                        ebayFile = EbayListingGenerator.generate(outputDir, vehicleTitle, records, finalPdf)
                    }
                }

                refreshIncomplete()
                _state.update {
                    it.copy(
                        phase = AppPhase.DONE,
                        finalPdfFile = finalPdf,
                        ebayInfoFile = ebayFile,
                        message = if (isStopped) "تم الحفظ الجزئي (${records.size} صفحة)" else "تم التحميل بنجاح (${records.size} صفحة)!"
                    )
                }
            } finally {
                stopService(Intent(this@MainActivity, DownloadService::class.java))
            }
        }
    }

    private fun shareFile(file: File) {
        val uri = FileProvider.getUriForFile(this, "${packageName}.fileprovider", file)
        val mime = if (file.name.endsWith(".pdf")) "application/pdf" else "text/plain"
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = mime
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(intent, "مشاركة / حفظ الملف"))
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun AutoWireScreen(
    state: UiState,
    onUrlChange: (String) -> Unit,
    onOpenUrl: () -> Unit,
    onScanPage: () -> Unit,
    onToggleCategory: (Int) -> Unit,
    onSelectAll: (Boolean) -> Unit,
    onStartDownload: () -> Unit,
    onResumeJob: (IncompleteJob) -> Unit,
    onPauseToggle: () -> Unit,
    onStopDownload: () -> Unit,
    onRetryBlocked: () -> Unit,
    onReset: () -> Unit,
    onShareFile: (File) -> Unit,
    onWebViewReady: (WebView) -> Unit
) {
    val bg = Color(0xFF0B1120)
    val card = Color(0xFF111827)
    val accent = Color(0xFF3B82F6)
    val okColor = Color(0xFF10B981)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(bg)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(card, RoundedCornerShape(12.dp))
                .padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("⚡ AutoWire", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text(state.phase.name, color = Color(0xFF60A5FA), fontSize = 12.sp)
        }

        Text(
            text = state.message,
            color = Color(0xFF93C5FD),
            fontSize = 13.sp,
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF0F172A), RoundedCornerShape(10.dp))
                .padding(10.dp)
        )

        val wvHeight = if (state.phase == AppPhase.BROWSER) 360.dp else 1.dp
        Box(modifier = Modifier.fillMaxWidth().height(wvHeight)) {
            AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { ctx ->
                    WebView(ctx).apply {
                        settings.javaScriptEnabled = true
                        settings.domStorageEnabled = true
                        settings.useWideViewPort = true
                        settings.loadWithOverviewMode = true
                        CookieManager.getInstance().setAcceptCookie(true)
                        CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
                        webViewClient = WebViewClient()
                        webChromeClient = WebChromeClient()
                        onWebViewReady(this)
                    }
                }
            )
        }

        if (state.phase == AppPhase.IDLE || state.phase == AppPhase.BROWSER) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(card, RoundedCornerShape(12.dp))
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = state.urlInput,
                    onValueChange = onUrlChange,
                    placeholder = { Text("https://en.kolhosniki.ru/... or https://kiagds.ru/...", color = Color.Gray) },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    )
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = onOpenUrl, colors = ButtonDefaults.buttonColors(containerColor = accent)) {
                        Text("فتح الرابط")
                    }
                    if (state.phase == AppPhase.BROWSER) {
                        Button(onClick = onScanPage, colors = ButtonDefaults.buttonColors(containerColor = okColor)) {
                            Text("فحص المخططات", color = Color.Black, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            if (state.phase == AppPhase.IDLE && state.incompleteJobs.isNotEmpty()) {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(state.incompleteJobs) { job ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(card, RoundedCornerShape(10.dp))
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(job.vehicleTitle, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Text("${job.done} / ${job.total} مخطط", color = Color.Gray, fontSize = 12.sp)
                            }
                            Button(onClick = { onResumeJob(job) }, colors = ButtonDefaults.buttonColors(containerColor = accent)) {
                                Text("استكمال")
                            }
                        }
                    }
                }
            }
        }

        if (state.phase == AppPhase.SELECTING) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { onSelectAll(true) }) { Text("تحديد الكل") }
                Button(onClick = { onSelectAll(false) }) { Text("إلغاء الكل") }
                Button(onClick = onStartDownload, colors = ButtonDefaults.buttonColors(containerColor = okColor)) {
                    Text("ابدأ التحميل", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            }
            LazyColumn(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                items(state.categories.size) { idx ->
                    val c = state.categories[idx]
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(card, RoundedCornerShape(8.dp))
                            .clickable { onToggleCategory(idx) }
                            .padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(checked = c.selected, onCheckedChange = { onToggleCategory(idx) })
                        Text("${c.name} (${c.count})", color = Color.White, modifier = Modifier.weight(1f))
                    }
                }
            }
        }

        if (state.phase == AppPhase.DOWNLOADING || state.phase == AppPhase.PAUSED || state.phase == AppPhase.BLOCKED) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(card, RoundedCornerShape(12.dp))
                    .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(state.vehicleTitle, color = Color.White, fontWeight = FontWeight.Bold)
                val pct = if (state.total > 0) state.current.toFloat() / state.total.toFloat() else 0f
                LinearProgressIndicator(progress = { pct }, modifier = Modifier.fillMaxWidth())
                Text("${state.current} / ${state.total} - ${state.currentItem}", color = Color.LightGray, fontSize = 12.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = onPauseToggle) {
                        Text(if (state.phase == AppPhase.PAUSED) "استئناف" else "إيقاف مؤقت")
                    }
                    if (state.phase == AppPhase.BLOCKED) {
                        Button(onClick = onRetryBlocked, colors = ButtonDefaults.buttonColors(containerColor = okColor)) {
                            Text("إعادة المحاولة", color = Color.Black)
                        }
                    }
                    Button(onClick = onStopDownload, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEF4444))) {
                        Text("إيقاف وحفظ PDF")
                    }
                }
            }
        }

        if (state.phase == AppPhase.DONE) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(card, RoundedCornerShape(12.dp))
                    .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                state.finalPdfFile?.let { pdf ->
                    Button(onClick = { onShareFile(pdf) }, colors = ButtonDefaults.buttonColors(containerColor = okColor)) {
                        Text("مشاركة / حفظ الـ PDF (${pdf.name})", color = Color.Black, fontWeight = FontWeight.Bold)
                    }
                }
                state.ebayInfoFile?.let { eb ->
                    Button(onClick = { onShareFile(eb) }, colors = ButtonDefaults.buttonColors(containerColor = accent)) {
                        Text("مشاركة eBay_Listing_Info.txt")
                    }
                }
                Button(onClick = onReset) { Text("تحميل عربية جديدة") }
            }
        }

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(140.dp)
                .background(Color(0xFF050811), RoundedCornerShape(10.dp))
                .border(1.dp, Color(0xFF1F2937), RoundedCornerShape(10.dp))
                .padding(8.dp)
        ) {
            LazyColumn {
                items(state.logs) { line ->
                    Text(line, color = Color(0xFFA7F3D0), fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                }
            }
        }
    }
}
