package com.autowire.app

import android.content.Context
import android.graphics.Color
import android.graphics.pdf.PdfDocument
import android.os.Handler
import android.os.Looper
import android.view.View
import android.webkit.WebView
import android.webkit.WebViewClient
import com.tom_roush.pdfbox.io.MemoryUsageSetting
import com.tom_roush.pdfbox.multipdf.PDFMergerUtility
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.interactive.documentnavigation.destination.PDPageFitDestination
import com.tom_roush.pdfbox.pdmodel.interactive.documentnavigation.outline.PDDocumentOutline
import com.tom_roush.pdfbox.pdmodel.interactive.documentnavigation.outline.PDOutlineItem
import kotlinx.coroutines.suspendCancellableCoroutine
import java.io.File
import java.io.FileOutputStream
import kotlin.coroutines.resume

object PdfEngine {

    private const val PAGE_W = 842
    private const val PAGE_H = 595
    private const val VIEW_W = 1684
    private const val VIEW_H = 1190

    private fun buildRenderHtml(payload: DiagramPayload, headerText: String): String {
        val escHeader = headerText
            .replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")

        val bodyContent = when (payload.type) {
            "svg" -> payload.content
            "img" -> "<img src=\"${payload.content}\" style=\"max-width:100%;max-height:100%;object-fit:contain;\"/>"
            else -> payload.content
        }

        return """<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<style>
  * { box-sizing: border-box; }
  html, body {
    margin: 0; padding: 0; width: 100%; height: 100%;
    background: #ffffff; color: #111827;
    font-family: sans-serif;
  }
  .hdr {
    height: 36px; line-height: 36px; padding: 0 18px;
    background: #0f172a; color: #f8fafc;
    font-size: 15px; font-weight: bold;
    white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
  }
  .wrap {
    width: 100%; height: calc(100vh - 36px);
    padding: 12px; display: flex; align-items: center; justify-content: center;
    overflow: hidden;
  }
  .wrap svg {
    max-width: 100% !important;
    max-height: 100% !important;
    width: auto !important;
    height: auto !important;
  }
  .wrap table { border-collapse: collapse; font-size: 13px; }
  .wrap td, .wrap th { border: 1px solid #cbd5e1; padding: 4px 6px; }
</style>
</head>
<body>
  <div class="hdr">$escHeader</div>
  <div class="wrap">$bodyContent</div>
</body>
</html>"""
    }

    suspend fun renderDiagramToPdf(
        context: Context,
        payload: DiagramPayload,
        headerText: String,
        outPdf: File
    ) = suspendCancellableCoroutine<Unit> { cont ->
        val mainHandler = Handler(Looper.getMainLooper())
        mainHandler.post {
            val wv = WebView(context)
            wv.setBackgroundColor(Color.WHITE)
            wv.settings.javaScriptEnabled = false
            wv.settings.loadWithOverviewMode = true
            wv.settings.useWideViewPort = true
            wv.layout(0, 0, VIEW_W, VIEW_H)

            wv.webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView?, url: String?) {
                    mainHandler.postDelayed({
                        try {
                            val wSpec = View.MeasureSpec.makeMeasureSpec(VIEW_W, View.MeasureSpec.EXACTLY)
                            val hSpec = View.MeasureSpec.makeMeasureSpec(VIEW_H, View.MeasureSpec.EXACTLY)
                            wv.measure(wSpec, hSpec)
                            wv.layout(0, 0, VIEW_W, VIEW_H)

                            val doc = PdfDocument()
                            val pageInfo = PdfDocument.PageInfo.Builder(PAGE_W, PAGE_H, 1).create()
                            val page = doc.startPage(pageInfo)
                            val canvas = page.canvas
                            canvas.scale(PAGE_W.toFloat() / VIEW_W.toFloat(), PAGE_H.toFloat() / VIEW_H.toFloat())
                            wv.draw(canvas)
                            doc.finishPage(page)

                            FileOutputStream(outPdf).use { fos ->
                                doc.writeTo(fos)
                            }
                            doc.close()
                        } catch (_: Exception) {
                        } finally {
                            wv.destroy()
                            if (cont.isActive) cont.resume(Unit)
                        }
                    }, 350)
                }
            }

            val html = buildRenderHtml(payload, headerText)
            wv.loadDataWithBaseURL("https://localhost/", html, "text/html", "UTF-8", null)
        }
    }

    fun mergePdfsWithBookmarks(records: List<DownloadedRecord>, finalPdf: File) {
        val valid = records.filter { it.pdfFile.exists() && it.pdfFile.length() > 500 }
        if (valid.isEmpty()) return

        val tempMerged = File(finalPdf.parentFile, "_temp_merged.pdf")
        val merger = PDFMergerUtility()
        merger.destinationFileName = tempMerged.absolutePath
        valid.forEach { merger.addSource(it.pdfFile) }
        merger.mergeDocuments(MemoryUsageSetting.setupTempFileOnly())

        PDDocument.load(tempMerged).use { doc ->
            val outline = PDDocumentOutline()
            doc.documentCatalog.documentOutline = outline

            val folderNodes = mutableMapOf<List<String>, PDOutlineItem>()
            var pageIdx = 0

            for (rec in valid) {
                val pagesInRec = try {
                    PDDocument.load(rec.pdfFile).use { it.numberOfPages }
                } catch (_: Exception) {
                    1
                }
                if (pageIdx >= doc.numberOfPages) break

                val dest = PDPageFitDestination().apply {
                    page = doc.getPage(pageIdx)
                }

                var parentNode: PDOutlineItem? = null
                val accPath = mutableListOf<String>()
                for (folderName in rec.path) {
                    accPath.add(folderName)
                    val key = accPath.toList()
                    var node = folderNodes[key]
                    if (node == null) {
                        node = PDOutlineItem().apply {
                            title = folderName
                            destination = dest
                        }
                        if (parentNode == null) {
                            outline.addLast(node)
                        } else {
                            parentNode.addLast(node)
                        }
                        folderNodes[key] = node
                    }
                    parentNode = node
                }

                val leaf = PDOutlineItem().apply {
                    title = rec.title
                    destination = dest
                }
                if (parentNode == null) {
                    outline.addLast(leaf)
                } else {
                    parentNode.addLast(leaf)
                }
                pageIdx += pagesInRec
            }

            doc.save(finalPdf)
        }
        tempMerged.delete()
    }
}
