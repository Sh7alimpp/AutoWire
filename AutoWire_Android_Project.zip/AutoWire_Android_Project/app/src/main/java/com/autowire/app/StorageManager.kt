package com.autowire.app

import android.content.Context
import android.os.Environment
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.security.MessageDigest

object StorageManager {

    fun getBaseDir(context: Context): File {
        val docs = context.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS) ?: context.filesDir
        val dir = File(docs, "AutoWire")
        if (!dir.exists()) dir.mkdirs()
        return dir
    }

    fun sanitizeFilename(name: String): String {
        val cleaned = name.replace(Regex("[\\\\/*?:\"<>|]+"), "_")
            .replace(Regex("\\s+"), " ")
            .trim()
        return if (cleaned.isNotEmpty()) cleaned.take(90) else "diagram"
    }

    fun buildOutputFolder(context: Context, startUrl: String, vehicleTitle: String, suffix: String = ""): File {
        val md = MessageDigest.getInstance("MD5")
        val digest = md.digest((startUrl + suffix).toByteArray(Charsets.UTF_8))
        val shortHash = digest.take(3).joinToString("") { "%02x".format(it) }
        val cleanTitle = sanitizeFilename(vehicleTitle).replace(" ", "_")
        val folderName = if (suffix.isNotEmpty()) {
            val cleanSuffix = sanitizeFilename(suffix).replace(" ", "_").take(40)
            "${cleanTitle}_${cleanSuffix}_$shortHash"
        } else {
            "${cleanTitle}_$shortHash"
        }
        val dir = File(getBaseDir(context), folderName)
        if (!dir.exists()) dir.mkdirs()
        return dir
    }

    fun saveResumeState(outputDir: File, vehicleTitle: String, catSuffix: String, startUrl: String, items: List<DiagramItem>) {
        val root = JSONObject().apply {
            put("vehicle_title", vehicleTitle)
            put("cat_suffix", catSuffix)
            put("start_url", startUrl)
            put("items", JSONArray().apply {
                items.forEach { it ->
                    put(JSONObject().apply {
                        put("title", it.title)
                        put("url", it.url)
                        put("path", JSONArray(it.path))
                    })
                }
            })
        }
        File(outputDir, "resume_state.json").writeText(root.toString(2), Charsets.UTF_8)
    }

    fun loadMetaTitles(outputDir: File): MutableMap<String, String> {
        val f = File(outputDir, "meta_titles.json")
        val map = mutableMapOf<String, String>()
        if (!f.exists()) return map
        try {
            val obj = JSONObject(f.readText(Charsets.UTF_8))
            obj.keys().forEach { k -> map[k] = obj.optString(k, "") }
        } catch (_: Exception) {}
        return map
    }

    fun saveMetaTitles(outputDir: File, map: Map<String, String>) {
        try {
            val obj = JSONObject()
            map.forEach { (k, v) -> obj.put(k, v) }
            File(outputDir, "meta_titles.json").writeText(obj.toString(2), Charsets.UTF_8)
        } catch (_: Exception) {}
    }

    fun findIncompleteJobs(context: Context): List<IncompleteJob> {
        val base = getBaseDir(context)
        val jobs = mutableListOf<IncompleteJob>()
        val dirs = base.listFiles()?.filter { it.isDirectory }?.sortedBy { it.name } ?: return jobs
        for (sub in dirs) {
            val inc = File(sub, "_INCOMPLETE.txt")
            val stateFile = File(sub, "resume_state.json")
            if (!inc.exists() || !stateFile.exists()) continue
            try {
                val obj = JSONObject(stateFile.readText(Charsets.UTF_8))
                val arr = obj.optJSONArray("items") ?: continue
                val items = mutableListOf<DiagramItem>()
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    val pArr = o.optJSONArray("path")
                    val pathList = mutableListOf<String>()
                    if (pArr != null) {
                        for (j in 0 until pArr.length()) pathList.add(pArr.getString(j))
                    }
                    items.add(
                        DiagramItem(
                            path = if (pathList.isEmpty()) listOf("WIRING DIAGRAMS") else pathList,
                            title = o.optString("title", "Diagram"),
                            url = o.optString("url", "")
                        )
                    )
                }
                if (items.isEmpty()) continue
                val pagesDir = File(sub, "pages")
                var doneEst = 0
                if (pagesDir.exists()) {
                    items.forEachIndexed { idx, it ->
                        val sb = "%03d_%s".format(idx + 1, sanitizeFilename(it.title))
                        val fp = File(pagesDir, "$sb.pdf")
                        if (fp.exists() && fp.length() > 1000) doneEst++
                    }
                }
                jobs.add(
                    IncompleteJob(
                        dir = sub,
                        dirName = sub.name,
                        vehicleTitle = obj.optString("vehicle_title", sub.name),
                        catSuffix = obj.optString("cat_suffix", ""),
                        startUrl = obj.optString("start_url", ""),
                        items = items,
                        done = doneEst,
                        total = items.size
                    )
                )
            } catch (_: Exception) {}
        }
        return jobs
    }
}
