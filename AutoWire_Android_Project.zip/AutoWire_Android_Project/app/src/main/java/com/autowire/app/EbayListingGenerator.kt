package com.autowire.app

import java.io.File

object EbayListingGenerator {

    private fun cleanVeroText(text: String): String {
        val banned = listOf(
            "ALLDATA", "Alldata", "Mitchell", "MITCHELL", "OnDemand",
            "Kolhosniki", "kolhosniki", "ServiceBox", "SEDRE", "TIS 2000", "TIS2000",
            "Ford TIS", "HaynesPro", "WorkshopData", "ELSA", "ElsaWin", "kiagds"
        )
        var t = text
        for (b in banned) {
            t = t.replace(b, "", ignoreCase = true)
        }
        return t.replace(Regex("\\s+"), " ").trim(' ', '-', '|', ',')
    }

    fun generate(
        outputDir: File,
        vehicleTitle: String,
        records: List<DownloadedRecord>,
        finalPdf: File
    ): File {
        val safeVehicle = cleanVeroText(vehicleTitle).ifEmpty { "Vehicle" }
        val totalPages = records.size

        var title = "$safeVehicle Color Wiring Diagram Schematic PDF ($totalPages Pages)"
        if (title.length > 80) {
            title = "$safeVehicle Wiring Diagram Schematic PDF"
        }
        if (title.length > 80) {
            title = title.take(77).trim() + "..."
        }

        val catCounts = linkedMapOf<String, Int>()
        for (r in records) {
            val top = cleanVeroText(r.path.firstOrNull() ?: "Wiring Diagrams").ifEmpty { "Wiring Diagrams" }
            catCounts[top] = (catCounts[top] ?: 0) + 1
        }
        val contentsBlock = catCounts.entries.joinToString("\n") { "- ${it.key} (${it.value} diagrams)" }

        val txt = """
=================================================================
  EBAY LISTING INFORMATION (DIGITAL DELIVERY)
=================================================================

[EBAY TITLE - <= 80 CHARS]
$title

-----------------------------------------------------------------
[EBAY DESCRIPTION - COPY & PASTE]
-----------------------------------------------------------------
$safeVehicle - Complete Color Wiring Diagram Schematic (Interactive Bookmarked PDF)

Product Details:
- Vehicle: $safeVehicle
- Format: High-Resolution Color PDF with Interactive Bookmarks
- Total Pages: $totalPages Pages
- Zoomable & Printable vector/high-clarity diagrams for easy troubleshooting

What's Included in This Wiring Diagram PDF:
$contentsBlock

Delivery Information:
- This is a DIGITAL DOWNLOAD (no physical item or CD/USB will be shipped).
- A secure digital download link will be sent directly to you via eBay Messages within 1 to 6 hours after payment is confirmed.
- No returns accepted on digital items.

-----------------------------------------------------------------
[RECOMMENDED EBAY LISTING SETTINGS]
-----------------------------------------------------------------
- Category: Other Information Products / Digital Download
- Quantity: 1
- Product documents toggle: OFF
- Item Location: Cairo, Egypt
- Handling Time: Same business day
- Returns: No returns accepted
- PDF File to Upload to Drive: ${finalPdf.name}
=================================================================
""".trimIndent() + "\n"

        val outFile = File(outputDir, "eBay_Listing_Info.txt")
        outFile.writeText(txt, Charsets.UTF_8)
        return outFile
    }
}
