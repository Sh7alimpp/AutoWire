package com.autowire.app

import android.os.Handler
import android.os.Looper
import android.webkit.CookieManager
import android.webkit.WebView
import kotlinx.coroutines.delay
import kotlinx.coroutines.suspendCancellableCoroutine
import org.json.JSONArray
import org.json.JSONObject
import java.net.URI
import kotlin.coroutines.resume

object WebExtractor {

    private val mainHandler = Handler(Looper.getMainLooper())

    suspend fun evalJs(webView: WebView, script: String): String = suspendCancellableCoroutine { cont ->
        mainHandler.post {
            webView.evaluateJavascript(script) { result ->
                if (cont.isActive) cont.resume(result ?: "null")
            }
        }
    }

    private fun unquoteJsJson(raw: String): String {
        if (raw == "null" || raw.isEmpty()) return ""
        return try {
            JSONObject("{\"v\":$raw}").get("v").toString()
        } catch (_: Exception) {
            raw.trim('"')
        }
    }

    suspend fun navigateAndWait(webView: WebView, url: String, waitMs: Long = 2200L) {
        mainHandler.post {
            CookieManager.getInstance().flush()
            webView.loadUrl(url)
        }
        delay(waitMs)
        for (i in 0..12) {
            val ready = unquoteJsJson(
                evalJs(
                    webView,
                    """(function(){
                        if (document.readyState === 'loading') return '0';
                        const area = document.querySelector('#standAloneElectronics, #diagram-box, #content, #goTextTop, .col[lvl="2"], .elsaContent2, section.wrapper, article#main') || document.body;
                        if (!area) return '1';
                        const txt = (area.innerText || '').toLowerCase();
                        if (txt.includes('loading...')) return '0';
                        return '1';
                    })()"""
                )
            )
            if (ready == "1") break
            delay(500)
        }
    }

    suspend fun getCurrentUrl(webView: WebView): String = suspendCancellableCoroutine { cont ->
        mainHandler.post {
            if (cont.isActive) cont.resume(webView.url ?: "")
        }
    }

    suspend fun dismissOverlays(webView: WebView) {
        evalJs(
            webView,
            """(function(){
                try { window.showTime1 = function(){}; } catch(e){}
                document.querySelectorAll('.time1Over, .upa, #dialog').forEach(el => {
                    el.style.setProperty('display','none','important');
                });
            })()"""
        )
    }

    suspend fun isBlockedPage(webView: WebView): String {
        val raw = evalJs(
            webView,
            """(function(){
                const u = (window.location.href || '').toLowerCase();
                if (u.includes('zaebal2.php')) return 'zaebal2.php block page';
                const t = (document.body ? document.body.innerText : '').toLowerCase();
                if (t.includes('403 access denied') || t.trim().startsWith('403 ')) return '403 Access denied';
                if (t.includes("don't try download this site") || t.includes('не пытайтесь скачать')) return "Anti-download warning";
                return '';
            })()"""
        )
        return unquoteJsJson(raw)
    }

    suspend fun extractVehicleTitle(webView: WebView): String {
        val raw = evalJs(
            webView,
            """(function(){
                const host = window.location.hostname.toLowerCase();
                if (host.includes('kiagds.ru')) {
                    const urlParams = new URLSearchParams(window.location.search || '');
                    const kiaParts = [];
                    for (const id of ['year', 'marke', 'model', 'mkb']) {
                        const sel = document.getElementById(id);
                        if (!sel) continue;
                        let txt = '';
                        if (sel.selectedIndex >= 0) {
                            const opt = sel.options[sel.selectedIndex];
                            const val = opt ? (opt.value || '').trim() : '';
                            const t = opt ? (opt.text || '').replace(/\s+/g, ' ').trim() : '';
                            if (t && val && val !== 'null' && !/^(make|year|model|engine)$/i.test(t)) txt = t;
                        }
                        if (!txt) {
                            const pv = (urlParams.get(id) || '').trim();
                            if (pv) {
                                const mo = Array.from(sel.options).find(o => (o.value || '').trim() === pv);
                                txt = (mo && mo.text) ? mo.text.replace(/\s+/g, ' ').trim() : (id === 'year' ? pv : '');
                            }
                        }
                        if (txt) kiaParts.push(txt);
                    }
                    if (kiaParts.length >= 2) return kiaParts.join(' ');
                }
                if (host.includes('webdiag.name')) {
                    const md = document.querySelector('a[href*="modelDetail"]');
                    if (md && md.innerText.trim()) return md.innerText.replace(/\s+/g, ' ').trim();
                    const ov = document.querySelector('a[href*="modelOverview"]');
                    const mt = document.querySelector('a[href*="modelTypes"]');
                    const h1 = document.querySelector('h1, h2, .model-title');
                    const hp = [ov, mt, h1].map(e => e ? (e.innerText || '').replace(/\s+/g, ' ').trim() : '').filter(Boolean);
                    if (hp.length) return Array.from(new Set(hp)).join(' ');
                }
                const parts = [];
                const relOrder = ['year', 'marke', 'make', 'brand', 'model', 'motor', 'engine'];
                for (const rel of relOrder) {
                    const sel = document.querySelector('select[rel="' + rel + '"], select[name="' + rel + '"]');
                    if (sel && sel.selectedIndex >= 0) {
                        const opt = sel.options[sel.selectedIndex];
                        const val = opt ? (opt.value || '').trim() : '';
                        const txt = opt ? (opt.text || '').replace(/\s+/g, ' ').trim() : '';
                        if (txt && val && val !== 'null' && !/^(model year|brand|make|model|engine|select|--)/i.test(txt)) parts.push(txt);
                    }
                }
                if (parts.length >= 2) return parts.join(' ');
                const btn = document.querySelector('.b_motor, .carName');
                if (btn && btn.innerText.trim()) return btn.innerText.replace(/\s+/g, ' ').trim();
                const m = (document.body.innerText || '').match(/\b(19|20)\d\d\s+[^\n]{4,70}/);
                return m ? m[0].replace(/\s+/g, ' ').trim() : 'Wiring_Diagrams';
            })()"""
        )
        return unquoteJsJson(raw).ifEmpty { "Wiring_Diagrams" }
    }

    private fun resolveUrl(base: String, rel: String): String {
        return try {
            URI(base).resolve(rel).toString().split("#")[0]
        } catch (_: Exception) {
            rel
        }
    }

    suspend fun extractTreeItems(webView: WebView, startUrl: String): List<DiagramItem> {
        val currentUrl = getCurrentUrl(webView).ifEmpty { startUrl }
        val raw = evalJs(
            webView,
            """(function(){
                const host = window.location.hostname.toLowerCase();
                if (host.includes('webdiag.name')) {
                    const results = [];
                    const seen = new Set();
                    const els = Array.from(document.querySelectorAll(
                        'a[href*="electronicComponent"], a[href*="wiringDiagram"], a[href*="electronicLocationDetail"], ' +
                        '[data-url*="electronicComponent"], [data-url*="wiringDiagram"], [data-url*="electronicSystems"]'
                    ));
                    for (const el of els) {
                        if (el.closest('header, nav, footer, #header, .settings, .modal, .top-nav')) continue;
                        const rawUrl = (el.getAttribute('href') || el.getAttribute('data-url') || '').trim();
                        if (!rawUrl || rawUrl === '#' || rawUrl.toLowerCase().startsWith('javascript:')) continue;
                        let title = (el.innerText || el.textContent || el.getAttribute('title') || '').replace(/\s+/g, ' ').trim();
                        if (!title || /^(back|home|search|print|login|logout)$/i.test(title)) continue;
                        if (seen.has(rawUrl)) continue;
                        seen.add(rawUrl);
                        results.push({ path: ['ELECTRONICS'], title: title, src: rawUrl });
                    }
                    if (!results.length && document.querySelector('#standAloneElectronics svg, #vesaWiringDiagram')) {
                        const h = document.querySelector('#diagram-box h1, #diagram-box h2, .diagram-title, h1, h2');
                        const t = (h ? h.innerText : document.title || 'Wiring Diagram').replace(/\s+/g, ' ').trim();
                        results.push({ path: ['ELECTRONICS'], title: t || 'Wiring Diagram', src: window.location.href });
                    }
                    if (results.length) return JSON.stringify(results);
                }

                for (const key of Object.keys(window)) {
                    try {
                        const obj = window[key];
                        if (obj && typeof obj === 'object' && Array.isArray(obj.aNodes) && obj.aNodes.length > 1) {
                            if (typeof obj.openAll === 'function') try { obj.openAll(); } catch(e){}
                            const byId = {};
                            obj.aNodes.forEach(n => byId[n.id] = n);
                            const out = [];
                            for (const n of obj.aNodes) {
                                const u = (n.url || '').trim();
                                if (!u || u.startsWith('javascript:') || u === '#') continue;
                                const p = [];
                                let pid = n.pid;
                                const vis = new Set();
                                while (byId[pid] && !vis.has(pid)) {
                                    vis.add(pid);
                                    if (byId[pid].name && byId[pid].pid !== -1) p.unshift(byId[pid].name.replace(/<[^>]*>/g, '').trim());
                                    pid = byId[pid].pid;
                                }
                                out.push({ path: p.length ? p : ['WIRING DIAGRAMS'], title: (n.name || 'Diagram').replace(/<[^>]*>/g, '').trim(), src: u });
                            }
                            if (out.length) return JSON.stringify(out);
                        }
                    } catch(e){}
                }

                const container = document.querySelector('ul.accordeon') || document.querySelector('#goMenuTop, .col[lvl="1"], .dtree, #dtree, .jstree');
                if (!container) return '[]';
                const results = [];
                const links = Array.from(container.querySelectorAll('a'));
                for (const a of links) {
                    if (a.closest('nav, header, footer')) continue;
                    const title = (a.innerText || a.textContent || '').replace(/\s+/g, ' ').trim();
                    if (!title) continue;
                    const lowT = title.toLowerCase();
                    if (lowT === 'translate' || lowT === 'disable ads') continue;
                    const onclick = (a.getAttribute('onclick') || '').trim();
                    const href = (a.getAttribute('href') || '').trim();
                    let targetSrc = '';
                    const m = onclick.match(/createImg\s*\(\s*['"]([^'"]+)['"]/i);
                    if (m && m[1]) targetSrc = m[1];
                    else if (onclick) {
                        const m2 = onclick.match(/['"]((?:https?:\/\/|\/)[^'"]*(?:ajax|docId|file=|svg|img|htm|html)[^'"]*)['"]/i);
                        if (m2 && m2[1]) targetSrc = m2[1];
                    }
                    if (!targetSrc && href && href !== '#' && !href.toLowerCase().startsWith('javascript:')) targetSrc = href;
                    if (!targetSrc) continue;

                    const path = [];
                    let li = a.closest('li');
                    let parentLi = li ? li.parentElement.closest('li') : null;
                    while (parentLi && container.contains(parentLi)) {
                        const labelEl = parentLi.querySelector(':scope > span, :scope > a, :scope > div');
                        if (labelEl && labelEl !== a && !labelEl.contains(a)) {
                            const fn = (labelEl.innerText || labelEl.textContent || '').replace(/\s+/g, ' ').trim();
                            if (fn) path.unshift(fn);
                        }
                        parentLi = parentLi.parentElement ? parentLi.parentElement.closest('li') : null;
                    }
                    let finalTitle = title;
                    let finalPath = path.slice();
                    if (host.includes('kiagds.ru')) {
                        if (finalPath.length && finalPath[0].toLowerCase() === 'english') finalPath.shift();
                        const lt = finalTitle.toLowerCase();
                        if ((lt === 'schematic diagrams' || lt === 'description and operation') && finalPath.length) {
                            finalTitle = finalPath.pop();
                        } else if (finalPath.length) {
                            finalTitle = finalPath[finalPath.length - 1] + ' - ' + finalTitle;
                        }
                    }
                    results.push({ path: finalPath.length ? finalPath : ['WIRING DIAGRAMS'], title: finalTitle, src: targetSrc });
                }
                return JSON.stringify(results);
            })()"""
        )

        val jsonStr = unquoteJsJson(raw)
        if (jsonStr.isEmpty() || jsonStr == "[]") return emptyList()
        val arr = JSONArray(jsonStr)
        val out = mutableListOf<DiagramItem>()
        val seen = mutableSetOf<String>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val fullU = resolveUrl(currentUrl, o.getString("src"))
            if (fullU in seen) continue
            seen.add(fullU)
            val pArr = o.getJSONArray("path")
            val pList = mutableListOf<String>()
            for (j in 0 until pArr.length()) pList.add(pArr.getString(j))
            out.add(DiagramItem(pList, o.getString("title"), fullU))
        }
        return out
    }

    suspend fun fetchDiagramPayloads(
        webView: WebView,
        diagramUrl: String,
        depth: Int = 0,
        maxDepth: Int = 1,
        visited: MutableSet<String> = mutableSetOf()
    ): List<DiagramPayload> {
        val normUrl = diagramUrl.split("#")[0]
        if (normUrl in visited) return emptyList()
        visited.add(normUrl)

        navigateAndWait(webView, normUrl)
        dismissOverlays(webView)
        val blk = isBlockedPage(webView)
        if (blk.isNotEmpty()) throw IllegalStateException("BLOCKED:$blk")

        val extractRaw = evalJs(
            webView,
            """(function(){
                const root = document.querySelector('#standAloneElectronics, #diagram-box, #content, #goTextTop, .col[lvl="2"], section.wrapper, article#main') || document.body;
                if (!root) return JSON.stringify({kind:'none'});
                const svgs = Array.from(root.querySelectorAll('svg'));
                let bestSvg = null, bestArea = 0;
                for (const s of svgs) {
                    if (s.innerHTML.trim().length < 50) continue;
                    const r = s.getBoundingClientRect();
                    if ((r.width >= 150 || r.height >= 150) && (r.width * r.height > bestArea)) {
                        bestArea = r.width * r.height;
                        bestSvg = s.outerHTML;
                    }
                }
                if (bestSvg) {
                    const nextA = document.querySelector('.pagination a[aria-label="Next"]');
                    const nextHref = (nextA && !nextA.closest('.disabled')) ? nextA.getAttribute('href') : '';
                    return JSON.stringify({kind:'svg', content: bestSvg, nextHref: nextHref || ''});
                }
                const clone = root.cloneNode(true);
                clone.querySelectorAll('script, style, ins, .adsbygoogle, .bannoads, nav, header, footer, #header, #menu, #buttonsTop, #goMenuTop, .col[lvl="1"], .ya-share2, .upa, .time1Over, ul.accordeon, .dtree, #dtree, .modal, .wait, .tooltips, gm_callout, .zooms, .breadcrumb').forEach(e => e.remove());
                const imgs = Array.from(clone.querySelectorAll('img')).filter(i => i.naturalWidth >= 150);
                if (imgs.length === 1 && (clone.innerText || '').trim().length < 120) {
                    return JSON.stringify({kind:'img', content: imgs[0].src});
                }
                if ((clone.innerText || '').trim().length > 40 || imgs.length > 0) {
                    return JSON.stringify({kind:'html', content: clone.innerHTML});
                }
                return JSON.stringify({kind:'none'});
            })()"""
        )

        val jsonStr = unquoteJsJson(extractRaw)
        if (jsonStr.isEmpty()) return emptyList()
        val obj = JSONObject(jsonStr)
        val kind = obj.optString("kind", "none")
        val results = mutableListOf<DiagramPayload>()

        when (kind) {
            "svg" -> {
                results.add(DiagramPayload("svg", obj.getString("content")))
                val nextHref = obj.optString("nextHref", "")
                if (nextHref.isNotEmpty() && depth < 40) {
                    delay(2000)
                    val nextUrl = resolveUrl(normUrl, nextHref)
                    results.addAll(fetchDiagramPayloads(webView, nextUrl, depth + 1, maxDepth, visited))
                }
            }
            "img" -> results.add(DiagramPayload("img", obj.getString("content"), "png"))
            "html" -> results.add(DiagramPayload("html", obj.getString("content")))
        }
        return results
    }
}
